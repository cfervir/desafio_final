import { createContext } from "react";

const ContextUser = createContext();

export default ContextUser;