import { createContext } from "react";

const ContextData = createContext();

export default ContextData;